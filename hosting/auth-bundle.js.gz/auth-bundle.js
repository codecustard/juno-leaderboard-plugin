// Bundle entry point for Internet Identity authentication
import { AuthClient } from '@icp-sdk/auth/client';

// Export to window for use in relay.html
window.AuthClient = AuthClient;

console.log('Auth client loaded successfully');
